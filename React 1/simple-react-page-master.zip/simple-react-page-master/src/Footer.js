import React from "react"

export default function Footer(){
    return(
      <div className="footer">
        <p>All rights reserver copyrights &copy;{new Date().getFullYear()} . Developed by Ayesha Naveed</p>
      </div>
    )
  }